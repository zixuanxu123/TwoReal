/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package business.organization;

import business.organization.Organization.Type;
import business.role.CustomerRole;
import business.role.Role;
import java.util.ArrayList;

/**
 * 
 * @author Shirui.Wang<wangshirui19940202@hotmail.com>
 */
public class CustomerOrganization extends Organization{

    public CustomerOrganization() {
        super(Type.Customer.getValue());
    }

    @Override
    public ArrayList<Role> getSupportedRole() {
        ArrayList<Role> roles = new ArrayList<>();
        roles.add(new CustomerRole());
        return roles;
    }
}
