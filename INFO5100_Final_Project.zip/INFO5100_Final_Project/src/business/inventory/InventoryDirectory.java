/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package business.inventory;

import business.item.Item;
import java.util.ArrayList;

/**
 *
 * @author Accelarator
 */
public class InventoryDirectory {

    private ArrayList<Inventory> inventoryDirectory;

    public InventoryDirectory() {
        inventoryDirectory = new ArrayList<Inventory>();
        newInventory();
    }

    public void newInventory(){
        Inventory inventory1=new Inventory();
        inventory1.setProductID(00102);
        inventory1.setProductName("2m Pipe");
        inventory1.setStock(50);
        inventory1.setUnitprice(80);
        
        Inventory inventory2=new Inventory();
        inventory2.setProductID(20100);
        inventory2.setProductName("10m Pipe");
        inventory2.setStock(16);
        inventory2.setUnitprice(86);
        
        this.inventoryDirectory.add(inventory1);
        this.inventoryDirectory.add(inventory2);
    }
    
    public ArrayList<Inventory> getInventoryDirectory() {
        return inventoryDirectory;
    }

    public void setInventoryDirectory(ArrayList<Inventory> inventoryDirectory) {
        this.inventoryDirectory = inventoryDirectory;
    }
    
}
